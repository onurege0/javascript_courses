import React from "react";
import axios from "axios";
import { useState } from "react";

const useStudent = () => {
  const [studentList, setStudentList] = useState([]);

  //   useEffect(() => {
  //     fetch("http://localhost:3000/students")
  //       .then((response) => response.json())
  //       .then((response) => setStudentList(response));
  //     // return (() => )
  //   }, []);

  const getStudents = async () => {
    try {
      const response = await axios("http://localhost:3000/students");
      setStudentList(response.data);
    } catch (error) {
      console.log(error);
    }
  };

  const createStudent = async (newStudent) => {
    const response = await axios.post(
      "http://localhost:3000/students",
      newStudent
    );
    console.log(response);
    setStudentList((prevStudentList) => [...prevStudentList, response.data]);
  };

  const deleteStudent = async (id) => {
    const response = await axios.delete(`http://localhost:3000/students/${id}`);
    console.log(response);
    setStudentList(studentList.filter((student) => student.id !== id));
  };

  return { studentList, createStudent, deleteStudent, getStudents };
};

export default useStudent;
